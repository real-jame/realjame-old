---
type: page
layout: default
title: "Contact"
draft: false
url: /contact
---

### ...with email!

Good old e-mail. I think it's the best for this form of communication! And, it's fun to send and recieve them too!

I would recommend email if you simply want to talk to me, doesn't matter what, I'd love to read what you have to say.

As seen on the footer, my email address is [james@realja.me](james@realja.me)!

### And my other accounts:

- Discord: realjame#3946
- GitHub: [@real-jame](https://github.com/real-jame)
- Twitter: [@real\_\_jame](https://twitter.com/real__jame)
- YouTube: [@realjame](https://www.youtube.com/@realjame)
