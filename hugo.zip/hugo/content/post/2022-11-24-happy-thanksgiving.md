---
categories:
- Personal
date: "2022-11-24T00:00:00Z"
description: "\U0001F983"
image: /blog/media/OldRoblox2010Thanksgiving.png
title: Happy Thanksgiving!
---

| ![Old Roblox screenshot of some players next to a turkey, outside of a house in the autumn fields.](/blog/media/OldRoblox2010Thanksgiving.png) |
| :--------------------------------------------------------------------------------------------------------------------------------------------: |
|                                                                   A "turkey"                                                                   |
